import numpy as np 
import glob
import os
import cv2
import re

annotation_folder = "FDDB-folds"
image_folder = "originalPics"
face_destination_folder = "train_face_images/"
nonface_destination_folder = "train_nonface_images/"
test_face_destination_folder = "test_face_images/"
test_nonface_destination_folder = "test_nonface_images/"

annotation_files = glob.glob(annotation_folder + '/*.txt')
k = 0
for i in range(0,len(annotation_files),2):
	file1 = open(annotation_files[i+1],"r")
	file_locations = file1.readlines()	
	for loc in range(0,len(file_locations)):
		k = k+1
		path_image = image_folder + "/" + file_locations[loc][:-1]
		param_file = open(annotation_files[i], "r")
		lineCount = 0
		for line in param_file:
		    lineCount += 1
		    if line.rstrip() == file_locations[loc][:-1] :
		    	break
		param_file.close()
		param_file = open(annotation_files[i], "r")
		lines = param_file.readlines()
		num_faces = lines[lineCount]
		if (num_faces[:-1] == '1' or 1 ):
		    data = lines[lineCount + 1]
		    vals = re.findall("\d+\.\d+", data)
		    vals = [float(i) for i in vals]
		    major_axis, minor_axis, _, center_x, center_y = map(int, vals)
		    img = cv2.imread(path_image + '.jpg')
		    rows,columns,channel = img.shape
		    img_face_cropped = img[center_y-major_axis:center_y+major_axis, center_x-minor_axis:center_x+minor_axis]
		    img_nonface = img[center_y + major_axis: rows,center_x + minor_axis: columns,]
		    
		    r1,c1,_ = img_face_cropped.shape
		    r2,c2,_ = img_nonface.shape
		    if(r1>60 and c1>60 and r2>60 and c2>60):
		        img_face_cropped = cv2.resize(img_face_cropped, (60,60))
		        img_nonface = cv2.resize(img_nonface, (60,60))
		        head, tail = os.path.split(path_image)
		        if(k<150):
			        cv2.imwrite(test_face_destination_folder+tail+'.jpg', img_face_cropped)
			        cv2.imwrite(test_nonface_destination_folder+tail+'.jpg', img_nonface)
		        else:
			        cv2.imwrite(face_destination_folder+tail+'.jpg', img_face_cropped)
			        cv2.imwrite(nonface_destination_folder+tail+'.jpg', img_nonface)